function [Y_tensor, A, X, Out]= LRATM_LRTC(Y, data, A, X, Y_tensorP,Nway, known, opts)
%%
% created by Haijin Zeng 
%
% 12/18/2020

% using BCD method
%%
%% Initiation
if isfield(opts,'mu');          mu = opts.mu;             else mu = 1;                 end
if isfield(opts,'tau');         tau = opts.tau;           else tau = 1;                end
if isfield(opts,'lambda');      lambda = opts.lambda;     else lambda = 1;             end
if isfield(opts,'beta') ;       beta = opts.beta;         else beta = 10;              end
if isfield(opts,'rho1') ;       rho1 = opts.rho1;         else rho1 = 0.1;             end
if isfield(opts,'rho2');        rho2 = opts.rho2;         else rho2 = 0.1;             end
if isfield(opts,'rho3');        rho3 = opts.rho3;         else rho3 = 0.1;             end
if isfield(opts,'maxit');       maxit = opts.maxit;       else maxit = 2000;           end
if isfield(opts,'initer');      initer = opts.initer;     else initer = 10;            end
if isfield(opts,'miter');       miter = opts.miter;       else miter = 20;             end
if isfield(opts,'tol');         tol = opts.tol;           else tol = 1e-4;             end
if isfield(opts,'alpha');       alpha = opts.alpha;       else alpha = [1/3 1/3 1/3];  end
Y_p=Y;X_p=X;A_p=A;
Z{1}=X{1};
Z{2}=X{2};
Z{3}=X{3};
J{1}=A{1};
J{2}=A{2};
J{3}=A{3};

Out.Res=[];Out.Real=[]; Out.PSNR=[];

rho1 = 0.1;
rho2 = 0.1;
rho3 = 0.1;

muu    = 1e-2;
Gamma1 = 0;
Gamma2 = 0;
Gamma3 = 0;
Tau1   = 0;
Tau2   = 0;
Tau3   = 0;


nrmb = norm(data);
res0 = zeros(1,3); TotalRes = 0;
res = res0;
for n = 1:3  
    Mn = Fold(X{n}*A{n},Nway,n);
    res0(n) = norm(Mn(known)-data); 
    TotalRes = TotalRes+res0(n);  
end
%%
fprintf('Iteration:     ');
for k=1: maxit
    fprintf('\b\b\b\b\b%5i',k);
    %% update Z    
    [s1,ss1,sss1] = size(X{1});
    [s2,ss2,sss2] = size(X{2});
    [s3,ss3,sss3] = size(X{3});
     sig1 = zeros(min(s1*ss1,sss1),1);
     sig2 = zeros(min(s2*ss2,sss2),1);
     sig3 = zeros(min(s3*ss3,sss3),1);
     gammaz = 0.1; % Sensitive parameter: gamma in L_{gamma}-norm
     strname = 'Lap';
     rhoz1 = 1e-2;
     rhoz2 = 1e-2;
     rhoz3 = 1e-2;
     tempp1 = X{1}+Gamma1/rho1;
     tempp2 = X{2}+Gamma2/rho2;
     tempp3 = X{3}+Gamma3/rho3;
     [Z{1},~] = L_solver( tempp1,rhoz1/2,sig1,gammaz,strname);      
     [Z{2},~] = L_solver( tempp2,rhoz2/2,sig2,gammaz,strname); 
     [Z{3},~] = L_solver( tempp3,rhoz3/2,sig3,gammaz,strname);
    
    %% update X 
    temp = alpha(1)*A_p{1}*A_p{1}'+rho1*(eye(size(A_p{1}*A_p{1}')));
    X{1} = (alpha(1)*Y_p{1}*A_p{1}'+rho1*(Z{1}-(Gamma1/rho1)))*pinv(temp);
    
    temp = alpha(2)*A_p{2}*A_p{2}'+rho2*(eye(size(A_p{2}*A_p{2}')));
    X{2} = (alpha(2)*Y_p{2}*A_p{2}'+rho2*(Z{2}-(Gamma2/rho2)))*pinv(temp);
    
    temp = alpha(3)*A_p{3}*A_p{3}'+rho3*(eye(size(A_p{3}*A_p{3}')));
    X{3} = (alpha(3)*Y_p{3}*A_p{3}'+rho3*(Z{3}-(Gamma3/rho3)))*pinv(temp);
    %% updata J 
    [t1,tt1,ttt1] = size(A{1});
    [t2,tt2,ttt2] = size(A{2});
    [t3,tt3,ttt3] = size(A{3});
     sig1 = zeros(min(t1*tt1,ttt1),1);
     sig2 = zeros(min(t2*tt2,ttt2),1);
     sig3 = zeros(min(t3*tt3,ttt3),1);
     gammaj = 5.0; 
     strname = 'Lap';
     rhoj1 = 1e-2;
     rhoj2 = 1e-2;
     rhoj3 = 1e-2;
     temp1 = A{1}+Tau1/rhoj1;
     temp2 = A{2}+Tau2/rhoj2;
     temp3 = A{3}+Tau3/rhoj3;
     [J{1},~] = L_solver( temp1,rhoj1/2,sig1,gammaj,strname);      
     [J{2},~] = L_solver( temp2,rhoj2/2,sig2,gammaj,strname); 
     [J{3},~] = L_solver( temp3,rhoj3/2,sig3,gammaj,strname); 
    %% updata A
    temp=X{1}'*X{1}+rho2*eye(size(X{1}'*X{1}));
    A{1}= pinv(temp)*(X{1}'*Y_p{1}+rho1*(J{1}-Tau1/rho1));
    
    temp=X{2}'*X{2}+rho2*eye(size(X{2}'*X{2}));
    A{2}= pinv(temp)*(X{2}'*Y_p{2}+rho2*(J{2}-Tau2/rho2));
    
    temp=X{3}'*X{3}+rho2*eye(size(X{3}'*X{3}));
    A{3}= pinv(temp)*(X{3}'*Y_p{3}+rho3*(J{3}-Tau3/rho3));
    

    % update Y 
    Y{1} = (X{1}*A{1}+rho3*Y_p{1})/(1+rho3); Y1 = Fold(Y{1}', Nway, 1); res(1) = norm(Y1(known)-data);
    
    Y{2} = (X{2}*A{2}+rho3*Y_p{2})/(1+rho3); Y2 = Fold(Y{2}', Nway, 2); res(2) = norm(Y2(known)-data);
    
    Y{3} = (X{3}*A{3}+rho3*Y_p{3})/(1+rho3); Y3 = Fold(Y{3}', Nway, 3); res(3) = norm(Y3(known)-data);
    
    Y_tensor = alpha(1)*Y1+alpha(2)*Y2+alpha(3)*Y3;
    muu    = 1e-2;
    Gamma1 = Gamma1 + muu*(X{1} - Z{1});
    Gamma2 = Gamma2 + muu*(X{2} - Z{2});
    Gamma3 = Gamma3 + muu*(X{3} - Z{3});
    Tau1 = Tau1 + muu*(A{1} - J{1});
    Tau2 = Tau2 + muu*(A{2} - J{2});
    Tau3 = Tau3 + muu*(A{3} - J{3});  
    
    real= norm(Y_tensor(known)-data)/ norm(data);
    Out.Real=[Out.Real,real];
    Y_tensor(known)= data;
    
    Res = norm(Y_tensor(:)-Y_tensorP(:))/norm(Y_tensorP(:));
    Out.Res = [Out.Res,Res];
    Y_tensorP = Y_tensor;

    TotalRes0 = TotalRes;  
    TotalRes = res(1)^2+res(2)^2+res(3)^2;
    relerr1 = abs(TotalRes-TotalRes0)/(TotalRes0+1);   
    relerr2 = sum(alpha.*res)/nrmb;
    Out.hist_rel(1,k) = relerr1;
    Out.hist_rel(2,k) = relerr2;
    
    % check stopping criterion
    crit = Res<tol;
    if crit
        break
    end
    
    if isfield(opts, 'Ytr')
        Out.truerel(k)= norm(Y_tensor(:)- opts.Ytr(:))/ norm(opts.Ytr(:));
        Out.PSNR(k) = PSNR(Y_tensor,opts.Ytr);
    end
    Y{1} = Unfold(Y_tensor,Nway,1); Y{1} = Y{1}';
    Y{2} = Unfold(Y_tensor,Nway,2); Y{2} = Y{2}';
    Y{3} = Unfold(Y_tensor,Nway,3); Y{3} = Y{3}';
    
    Y_p=Y;X_p=X;A_p=A;
end
end