
% created by Hai-Jin Zeng
% 2/03/2020
% Details will be updated in the future
clc; clear; close all;

addpath(genpath('tensor_toolbox'))
%% Select the model you want to run
EN_LRATM  = 1;
load video_suzie.mat
X=X(:,:,1:10); 
%% Set sampling ratio
% sr = 0.2;
sr = 0.2;

%% Initial data
if max(X(:))>1
X=X/max(X(:));
end

band    = 1; %the band to show and save
temp    = X(:,:,band);
maxI    = max(temp(:));
minI    = min(temp(:));
[~,~,p] = size(X);

Nway=[size(X,1), size(X,2), size(X,3)];
n1 = size(X,1); n2 = size(X,2); 
frames=size(X,3);
ratio = 0.005;
R=AdapN_Rank(X,ratio);
Y_tensorT = X;
maxP = max(abs(Y_tensorT(:)));
p = round(sr*prod(Nway));
known = randsample(prod(Nway),p); data = Y_tensorT(known);
[known, id]= sort(known); data= data(id);
Y_tensor0= zeros(Nway); Y_tensor0(known)= data;

% Initialization of the factor matrices X and A
for n = 1:3
    coNway(n) = prod(Nway)/Nway(n);
end
for i = 1:3
    Y0{i} = Unfold(Y_tensor0,Nway,i);
    Y0{i} = Y0{i}';
    X0{i}= rand(coNway(i), R(i));
    A0{i}= rand(R(i),Nway(i));
end

%% Begin the comlpetion with our LxLx_LRTC
i = i+1;
if EN_LRATM 
    fprintf('\n');
    disp('Begin the comlpetion with LxLx_DBNN')
    % Initialization of the parameters
    opts=[];
    opts.maxit=2000;
    opts.Ytr= Y_tensorT;
    % opts.tol=1e-4;
    opts.tol=1e-4;
    alpha=[1,1,1];
    opts.alpha = alpha / sum(alpha);
    % rho=0.1;
    rho=0.1;
    opts.rho1=rho;
    opts.rho2=rho;
    opts.rho3=rho;
    % opts.mu=1;
    opts.mu=1;
    opts.tau=0.1;
    opts.lambda=0.1;
    % opts.beta=10;
    opts.beta=10;
    opts.initer=10;
    opts.miter=20;
    [Y_LRATM, ~, ~, ~]= LRATM_LRTC(Y0, data, A0, X0,Y_tensor0, Nway, known, opts);
    Y_LRATM = max(Y_LRATM,0);
    Y_LRATM = min(Y_LRATM,maxP);
end
 %% Visualize image
 show_image = 1;
 if show_image
    subplot(131);imshow(X(:,:,10),[]);title('GT')
    subplot(132);imshow(Y_tensor0(:,:,10),[]);title('Sampled Tensor')
    subplot(133);imshow(Y_LRATM(:,:,10),[]);title('LRATM')
 end